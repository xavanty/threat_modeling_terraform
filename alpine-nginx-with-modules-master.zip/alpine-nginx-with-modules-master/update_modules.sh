#!/bin/bash

NGX_CACHE_PURGE_VERSION=2.3

# Main directory
mkdir -p modules
cd modules

# Addind Module nginx_cache_purge
rm -rf cachepurge 
mkdir -p cachepurge
echo "https://github.com/FRiCKLE/ngx_cache_purge/archive/${NGX_CACHE_PURGE_VERSION}.tar.gz" > cachepurge/source \
